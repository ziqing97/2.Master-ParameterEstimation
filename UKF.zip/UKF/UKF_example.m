clc
clear
close all

n=2;      %number of state
q=0.1;    %std of process 
r=0.1;    %std of measurement
Q=q^2*eye(n); % covariance of process
R=r^2;        % covariance of measurement  
%f=@(x)[x(2);x(3);0.05*x(1)*(x(2)+x(3))];  % nonlinear state equations
f=@(x)[sin(2*x(2));cos(2*x(1))];  % nonlinear state equations
h1=@(x)[x(1);x(2)];                               % measurement equation
h=@(x)[x(1)];                               % measurement equation
s=[0;0];                                % initial state
x=s+q*randn(n,1); %initial state          % initial state with noise
P = eye(n);                               % initial state covraiance
N=100;                                     % total dynamic steps
xV = zeros(n,N);          %estimate       % allocate memory
xV1 = zeros(n,N);          %estimate       % allocate memory
sV = zeros(n,N);          %actual
zV = zeros(1,N);
zV1 = zeros(2,N);
for k=1:N
  z = h(s) + r*randn;                     % measurments
  z1 = h1(s) + r*randn;                     % measurments
  sV(:,k)= s;                             % save actual state
  zV(:,k)  = z;                             % save measurment
  zV1(:,k)  = z1;                             % save measurment
  [x2, P2] = ukf(f,x,P,h,z,Q,R);            % ukf 
  [x1, P1] = ukf(f,x,P,h1,z1,Q,R);            % ukf
  xV(:,k) = x2;                            % save estimate
  xV1(:,k) = x1;                            % save estimate
  s = f(s) + q*randn(n,1);                % update process 
end
figure
for k=1:n                                 % plot results
  subplot(n,1,k)
  plot(1:N, sV(k,:), 'linewidth',2);hold on;plot(1:N, xV(k,:), 'linewidth',2); hold on
  plot(1:N,xV1(k,:), '.-r', 'linewidth',2)
end
legend('actual state','estimated state with measurements of x(1)','estimated state with measurements of x(1) and x(2)')

figure
for k=1:n                                 % plot results
  subplot(n,1,k)
  plot(1:N, sV(k,:)-xV(k,:), 'linewidth',2); hold on
  plot(1:N, sV(k,:)-xV1(k,:), 'linewidth',2)
 
end

legend('error, case:  measurements of x(1)','error, case: measurements of x(1) and x(2)')

figure
                                 % plot results
plot(sV(1,:),sV(2,:))

hold on

plot(xV1(1,:),xV1(2,:))






k = [0:N;0:N];
for i=1:length(k)
t(i,:)=f(k(:,i));
end
plot(t(:,1),t(:,2))